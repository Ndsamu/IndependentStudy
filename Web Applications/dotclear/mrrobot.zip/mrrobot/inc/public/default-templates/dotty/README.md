# Dotty

Un nouveau jeu de templates pour Dotclear (versions ≥ 2.10)

## Motivations

Le jeu de templates Dotty reprend la même structure que le jeu currywurst avec la différence qu'il tire parti des balises sémantiques spécifiques de HTML5 : section, article, aside, header, footer, …
