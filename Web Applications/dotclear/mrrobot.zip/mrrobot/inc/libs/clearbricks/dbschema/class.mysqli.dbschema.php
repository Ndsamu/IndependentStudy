<?php
/**
 * @class mysqliSchema
 *
 * @package Clearbricks
 * @subpackage DBSchema
 *
 * @copyright Olivier Meunier & Association Dotclear
 * @copyright GPL-2.0-only
 */

require_once 'class.mysql.dbschema.php';

class mysqliSchema extends mysqlSchema
{

}
