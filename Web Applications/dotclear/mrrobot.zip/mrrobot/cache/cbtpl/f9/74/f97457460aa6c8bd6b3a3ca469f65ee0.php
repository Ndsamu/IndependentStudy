
<?php try { echo $core->tpl->getData('_entry-content.html'); } catch (Exception $e) {} ?>


<?php try { echo $core->tpl->getData('_entry-feedback.html'); } catch (Exception $e) {} ?>

